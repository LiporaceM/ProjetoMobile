package com.example.projetotalento

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class VerificarEmail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verificar_email)
    }
}