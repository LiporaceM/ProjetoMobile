package com.example.diversain

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.example.diversain.LoginActivity


class MainActivity : AppCompatActivity() {

    private val SPLASH_DELAY: Long = 5000 // 5 segundos

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Iniciar temporizador para navegar para a tela de login após 5 segundos
        Handler().postDelayed({
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish() // Finalizar esta atividade para que o usuário não possa voltar para ela pressionando o botão "Voltar"
        }, SPLASH_DELAY)
    }
}
