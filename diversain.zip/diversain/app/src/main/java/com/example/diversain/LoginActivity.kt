package com.example.diversain

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import android.text.SpannableStringBuilder
import android.graphics.Color
import android.text.style.ForegroundColorSpan

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        // Get reference to the TextView
        val termosTextView = findViewById<TextView>(R.id.termosTextV)

        // Get the original text from the TextView
        val originalText = termosTextView.text.toString()

        // Define colors
        val colorTermos = Color.parseColor("#FF0000") // Red
        val colorPolitica = Color.parseColor("#0000FF") // Blue

        // Create a spannable string builder
        val spannableBuilder = SpannableStringBuilder(originalText)

        // Find indices of "Termos" and "Política de Privacidade" in the text
        val termosIndex = originalText.indexOf("Termos")
        val politicaIndex = originalText.indexOf("Política de Privacidade")

        // Apply colors to "Termos" and "Política de Privacidade"
        spannableBuilder.setSpan(
            ForegroundColorSpan(colorTermos),
            termosIndex,
            termosIndex + "Termos".length,
            SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        spannableBuilder.setSpan(
            ForegroundColorSpan(colorPolitica),
            politicaIndex,
            politicaIndex + "Política de Privacidade".length,
            SpannableStringBuilder.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        // Set the modified text to the TextView
        termosTextView.text = spannableBuilder
    }
}
